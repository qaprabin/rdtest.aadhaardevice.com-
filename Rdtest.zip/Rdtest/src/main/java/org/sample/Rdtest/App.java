package org.sample.Rdtest;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.io.StringReader;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import java.io.ByteArrayInputStream;

// CSV file imports
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.File;

public class App {
    String driverPath = "E:\\PrabinCh Maharana\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe";
    public static WebDriver driver;
    static int captureCount = 0; // Capture attempt counter..Prabin this line your capture count start line Just remember.

    @BeforeTest
    public void setup() {
        System.setProperty("webdriver.chrome.driver", driverPath);
        driver = new ChromeDriver();
        driver.navigate().to("https://rdtest.aadhaardevice.com/");
        driver.manage().window().maximize();
    }

    @Test(priority = 1, enabled = true)
    public static void Discover() {
        driver.findElement(By.xpath("//button[contains(text(),'Discover AVDM')]")).click(); //Clicks "Discover AVDM" button.
        WebDriverWait wait = new WebDriverWait(driver, 5); //wait for 5sec.
        Alert alert = wait.until(ExpectedConditions.alertIsPresent()); //for display alert popup
        System.out.println("\n  " + alert.getText()); //Print that popup messages with use getText(). Prints the detected AVDM and device info in console.
        alert.accept(); //Accepts alert popup.

        WebElement dis = driver.findElement(By.xpath("//select[@id='ddlAVDM']"));
        System.out.println("\n " + dis.getText());

        WebElement data = driver.findElement(By.xpath("//textarea[@id='txtDeviceInfo']"));
        System.out.println("\n Discover value is: " + data.getAttribute("value"));
    }

    @Test(priority = 2, enabled = true)
    public static void DeviceInfo() {
        WebDriverWait wait = new WebDriverWait(driver, 5);
        WebElement deviceInfoButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Device Info')]")));
        deviceInfoButton.click();

        WebElement data = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@id='txtDeviceInfo']")));
        System.out.println("\n Device Info value: " + data.getAttribute("value"));
    }

    @Test(priority = 3, enabled = true)
    public void selectEnvBeforeCapture() {
        selectEnv("PP");
    }

    public static void selectEnv(String visibleText) {
        try {
            WebElement envDropdown = driver.findElement(By.id("Env"));
            Select select = new Select(envDropdown);
            List<WebElement> options = select.getOptions();
            System.out.println("\n Available Env options:");
            for (WebElement option : options) {
                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
            }
            select.selectByVisibleText(visibleText);
            System.out.println(" Env selected: " + visibleText);
        } catch (Exception e) {
            System.out.println(" Failed to select ENV: " + visibleText);
            e.printStackTrace();
        }
    }

    @Test(priority = 4, enabled = true)
    public void selectDataTypeBeforeCapture() {
    	
        selectDataType("P");
    }

    public static void selectDataType(String visibleText) {
        try {
            WebElement dataTypeDropdown = driver.findElement(By.id("Dtype"));
            Select select = new Select(dataTypeDropdown);
            List<WebElement> options = select.getOptions();
            System.out.println("\n Available Data Type options:");
            for (WebElement option : options) {
                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
            }
            select.selectByVisibleText(visibleText);
            System.out.println(" Data Type selected: " + visibleText);
        } catch (Exception e) {
            System.out.println("\n Failed to select Data Type: " + visibleText);
            e.printStackTrace();
        }
    }

    @Test(priority = 5, enabled = true)
    public void selectFingerTypeBeforeCapture() {
        selectFingerType("FIR");
    }

    public static void selectFingerType(String visibleText) {
        try {
            WebElement fingerTypeDropdown = driver.findElement(By.id("Ftype"));
            Select select = new Select(fingerTypeDropdown);
            List<WebElement> options = select.getOptions();
            System.out.println("\n Available Finger Types:");
            for (WebElement option : options) {
                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
            }
            select.selectByVisibleText(visibleText);
            System.out.println(" Finger Type selected: " + visibleText);
        } catch (Exception e) {
            System.out.println(" Failed to select Finger Type: " + visibleText);
            e.printStackTrace();
        }
    }


//    // 🆕 NEW METHODS ADDED BELOW     For Iris
//    @Test(priority = 6, enabled = true)
//    public void selectFingerCountBeforeCapture() {
//        selectFingerCount("0");
//    }
//
//    public static void selectFingerCount(String visibleText) {
//        try {
//            WebElement fingerCountDropdown = driver.findElement(By.id("Fcount"));
//            Select select = new Select(fingerCountDropdown);
//            List<WebElement> options = select.getOptions();
//            System.out.println("\n Available Finger Count options:");
//            for (WebElement option : options) {
//                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
//            }
//            select.selectByVisibleText(visibleText);
//            System.out.println(" Finger Count selected: " + visibleText);
//        } catch (Exception e) {
//            System.out.println(" Failed to select Finger Count: " + visibleText);
//            e.printStackTrace();
//        }
//    }
   
//    // 🆕 NEW METHODS ADDED BELOW     For Iris
//    @Test(priority = 7, enabled = false)
//    public void selectIrisTypeBeforeCapture() {
//        selectIrisType("ISO");
//    }
//
//    public static void selectIrisType(String visibleText) {
//        try {
//            WebElement irisTypeDropdown = driver.findElement(By.id("Itype"));
//            Select select = new Select(irisTypeDropdown);
//            List<WebElement> options = select.getOptions();
//            System.out.println("\n Available Iris Type options:");
//            for (WebElement option : options) {
//                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
//            }
//            select.selectByVisibleText(visibleText);
//            System.out.println(" Iris Type selected: " + visibleText);
//        } catch (Exception e) {
//            System.out.println(" Failed to select Iris Type: " + visibleText);
//            e.printStackTrace();
//        }
//    }

    

//    // 🆕 NEW METHODS ADDED BELOW  For Iris  
//    @Test(priority = 8, enabled = false)
//    public void selectIrisCountBeforeCapture() {
//        selectIrisCount("2");
//    }
//
//    public static void selectIrisCount(String visibleText) {
//        try {
//            WebElement irisCountDropdown = driver.findElement(By.id("Icount"));
//            Select select = new Select(irisCountDropdown);
//            List<WebElement> options = select.getOptions();
//            System.out.println("\n Available Iris Count options:");
//            for (WebElement option : options) {
//                System.out.println(" - " + option.getText() + " : value=" + option.getAttribute("value"));
//            }
//            select.selectByVisibleText(visibleText);
//            System.out.println(" Iris Count selected: " + visibleText);
//        } catch (Exception e) {
//            System.out.println(" Failed to select Iris Count: " + visibleText);
//            e.printStackTrace();
//        }
//    }

    @Test(priority = 9, invocationCount = 5, enabled = true) // After set everything its your final fun.
    public static void Capture() {
        WebDriverWait wait = new WebDriverWait(driver, 5);
        captureCount++;
        System.out.println("\n Capture-" + captureCount);

        long startTime = System.currentTimeMillis(); // this line for start time for capture

        WebElement captureButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Capture')]")));
        captureButton.click();

        try {
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());
            System.out.println(" Capture Alert: " + alert.getText());
            alert.accept();
        } catch (Exception e) {
            System.out.println(" No alert for Capture.");
        }

        WebElement dataElement = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//textarea[@id='txtPidData']")));
        String responseData = dataElement.getAttribute("value").trim();
        
        long endTime = System.currentTimeMillis();
        double secondsTaken = (endTime - startTime) / 1000.0;
        System.out.printf(" Capture-%d Time duration: %.2f seconds%n", captureCount, secondsTaken);
        // these 3line for end your capture time.

        String respOutput = extractRespTag(responseData);

        String dataTypeValue = driver.findElement(By.id("Dtype")).getAttribute("value");
        String dataTypeLabel = dataTypeValue.equals("0") ? "X" : "P";

        writeToCSV(captureCount, respOutput, secondsTaken, dataTypeLabel);
    }

    @Test(priority = 10, enabled = true)
    public static String extractRespTag(String xmlData) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new ByteArrayInputStream(xmlData.getBytes()));

            Element respElement = (Element) doc.getElementsByTagName("Resp").item(0);
            if (respElement != null) {
                String respOutput = " <Resp " +
                    "errCode=\"" + respElement.getAttribute("errCode") + "\" " +
                    "errInfo=\"" + respElement.getAttribute("errInfo") + "\" " +
                    "fCount=\"" + respElement.getAttribute("fCount") + "\" " +
                    "fType=\"" + respElement.getAttribute("fType") + "\" " +
                    "nmPoints=\"" + respElement.getAttribute("nmPoints") + "\" " +
                    "qScore=\"" + respElement.getAttribute("qScore") + "\" />";
                System.out.println(respOutput);
                return respOutput;
            } else {
                System.out.println("Resp tag not found.");
                return "Resp tag not found.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error parsing Resp tag.";
        }
    }
    
    public static void writeToCSV(int captureCount, String respData, double duration, String dataType) {
        String filePath = "E:\\PrabinCh Maharana\\CSV file logs\\and.CSV";
        boolean fileExists = new File(filePath).exists();

        try (PrintWriter writer = new PrintWriter(new FileWriter(filePath, true))) {
            if (!fileExists) {
                writer.println("CaptureCount,RespData,DurationInSeconds,DataType");
            }
            writer.printf("%d,\"%s\",%.2f,\"%s\"%n",
                captureCount,
                respData.replace("\"", "\"\""),
                duration,
                dataType
            );
            System.out.println("\n Data written to CSV file successfully.\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @AfterTest
    public void tearDown() {
        if (driver != null) {
//            driver.close();
//            driver.quit();
        }
    }

}
