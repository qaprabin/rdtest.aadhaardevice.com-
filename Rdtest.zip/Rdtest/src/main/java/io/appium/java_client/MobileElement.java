package io.appium.java_client;

public class MobileElement {

}
